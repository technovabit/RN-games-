import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Stethoscope, Loader2, AlertTriangle, ArrowLeft, ShieldAlert, Activity, ThumbsUp } from "lucide-react";

interface Condition {
  name: string;
  probability: string;
  severity: string;
  description: string;
  recommendations: string[];
}

interface SymptomResult {
  conditions?: Condition[];
  general_advice?: string;
  should_see_doctor?: boolean;
  urgency?: string;
  error?: string;
}

const severityColor: Record<string, string> = {
  Low: "bg-success/10 text-success border-success/20",
  Medium: "bg-warning/10 text-warning border-warning/20",
  High: "bg-destructive/10 text-destructive border-destructive/20",
};

const urgencyConfig: Record<string, { icon: typeof Activity; label: string; className: string }> = {
  routine: { icon: ThumbsUp, label: "Routine", className: "gradient-primary" },
  soon: { icon: Activity, label: "See a Doctor Soon", className: "bg-warning" },
  urgent: { icon: ShieldAlert, label: "Urgent Care Needed", className: "bg-destructive" },
  emergency: { icon: ShieldAlert, label: "Emergency! Call 911", className: "bg-destructive" },
};

const SymptomChecker = () => {
  const [symptoms, setSymptoms] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<SymptomResult | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleAnalyze = async () => {
    if (!symptoms.trim()) return;
    setAnalyzing(true);
    setResult(null);

    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-symptoms`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ symptoms }),
        }
      );

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Analysis failed");
      }

      const data: SymptomResult = await res.json();

      if (data.error) {
        toast({ title: "Error", description: data.error, variant: "destructive" });
      } else {
        setResult(data);
        if (user) {
          await supabase.from("symptom_checks").insert({
            user_id: user.id,
            symptoms,
            ai_response: data as any,
            severity: data.urgency || "routine",
          });
        }
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setAnalyzing(false);
    }
  };

  if (result && !result.error) {
    const urgency = urgencyConfig[result.urgency || "routine"] || urgencyConfig.routine;
    const UrgencyIcon = urgency.icon;

    return (
      <div className="px-4 pt-6 safe-top space-y-4 pb-4">
        <button onClick={() => setResult(null)} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Check again
        </button>

        {/* Urgency banner */}
        <Card className={`rounded-2xl p-4 ${urgency.className} text-primary-foreground border-0 shadow-elevated animate-fade-in`}>
          <div className="flex items-center gap-3">
            <UrgencyIcon className="h-6 w-6" />
            <div>
              <p className="font-display font-bold">{urgency.label}</p>
              {result.should_see_doctor && (
                <p className="text-sm opacity-90">We recommend consulting a healthcare professional</p>
              )}
            </div>
          </div>
        </Card>

        {/* Conditions */}
        {result.conditions?.map((condition, i) => (
          <Card key={i} className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in" style={{ animationDelay: `${(i + 1) * 100}ms` }}>
            <div className="flex items-start justify-between mb-2">
              <h3 className="text-sm font-display font-semibold text-foreground">{condition.name}</h3>
              <div className="flex gap-1.5">
                <Badge variant="outline" className={`text-[10px] rounded-md ${severityColor[condition.severity] || ""}`}>
                  {condition.severity}
                </Badge>
                <Badge variant="secondary" className="text-[10px] rounded-md">
                  {condition.probability}
                </Badge>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-3">{condition.description}</p>
            {condition.recommendations?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-foreground mb-1">Recommendations:</p>
                <ul className="space-y-1">
                  {condition.recommendations.map((rec, j) => (
                    <li key={j} className="text-xs text-muted-foreground flex items-start gap-2">
                      <span className="text-primary mt-0.5">•</span> {rec}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </Card>
        ))}

        {/* General advice */}
        {result.general_advice && (
          <Card className="rounded-2xl p-4 shadow-card border-primary/20 bg-primary/5 animate-fade-in" style={{ animationDelay: "500ms" }}>
            <h3 className="text-sm font-display font-semibold text-primary mb-2">General Advice</h3>
            <p className="text-sm text-muted-foreground">{result.general_advice}</p>
          </Card>
        )}

        {/* Disclaimer */}
        <Card className="rounded-2xl p-3 bg-muted border-border/50 animate-fade-in" style={{ animationDelay: "600ms" }}>
          <div className="flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
            <p className="text-[11px] text-muted-foreground">
              This analysis is for <strong>informational purposes only</strong> and does not constitute medical advice. Always consult a qualified healthcare professional.
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="px-4 pt-6 safe-top space-y-6">
      <div className="animate-fade-in">
        <h1 className="text-xl font-display font-bold text-foreground">Symptom Checker</h1>
        <p className="text-sm text-muted-foreground mt-1">Describe your symptoms for AI analysis</p>
      </div>

      <Card className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in">
        <div className="flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 text-warning mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground">
            This is for informational purposes only and is <strong>not a medical diagnosis</strong>. Always consult a healthcare professional.
          </p>
        </div>
      </Card>

      <div className="space-y-4 animate-fade-in">
        <Textarea
          placeholder="Describe your symptoms in detail... (e.g., headache, fever, sore throat for 2 days)"
          value={symptoms}
          onChange={(e) => setSymptoms(e.target.value)}
          rows={5}
          className="rounded-xl bg-card shadow-card border-border/50 resize-none"
        />

        <div className="flex flex-wrap gap-2">
          {["Headache", "Fever", "Cough", "Fatigue", "Nausea", "Body ache", "Dizziness", "Sore throat"].map((s) => (
            <Badge
              key={s}
              variant="outline"
              className="cursor-pointer hover:bg-secondary transition-colors rounded-lg px-3 py-1"
              onClick={() => setSymptoms((prev) => prev ? `${prev}, ${s.toLowerCase()}` : s.toLowerCase())}
            >
              {s}
            </Badge>
          ))}
        </div>

        <Button onClick={handleAnalyze} className="w-full gradient-primary text-primary-foreground" disabled={analyzing || !symptoms.trim()}>
          {analyzing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Stethoscope className="h-4 w-4 mr-2" />}
          {analyzing ? "Analyzing Symptoms..." : "Analyze Symptoms"}
        </Button>
      </div>
    </div>
  );
};

export default SymptomChecker;
