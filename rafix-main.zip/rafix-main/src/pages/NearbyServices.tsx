import { Card } from "@/components/ui/card";
import { MapPin, Hospital, Pill } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const NearbyServices = () => {
  return (
    <div className="px-4 pt-6 safe-top space-y-6">
      <div className="animate-fade-in">
        <h1 className="text-xl font-display font-bold text-foreground">Nearby Services</h1>
        <p className="text-sm text-muted-foreground mt-1">Find hospitals, clinics & pharmacies near you</p>
      </div>

      {/* Map placeholder */}
      <Card className="rounded-2xl overflow-hidden shadow-card border-border/50 animate-fade-in">
        <div className="h-56 bg-secondary flex items-center justify-center">
          <div className="text-center">
            <MapPin className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Google Maps integration coming soon</p>
            <p className="text-xs text-muted-foreground mt-1">Requires Google Maps API key</p>
          </div>
        </div>
      </Card>

      {/* Filter tags */}
      <div className="flex gap-2 animate-fade-in">
        <Badge className="gradient-primary text-primary-foreground rounded-lg px-4 py-1.5 cursor-pointer">All</Badge>
        <Badge variant="outline" className="rounded-lg px-4 py-1.5 cursor-pointer hover:bg-secondary">
          <Hospital className="h-3 w-3 mr-1" /> Hospitals
        </Badge>
        <Badge variant="outline" className="rounded-lg px-4 py-1.5 cursor-pointer hover:bg-secondary">
          <Pill className="h-3 w-3 mr-1" /> Pharmacies
        </Badge>
      </div>

      {/* Placeholder list */}
      <div className="space-y-3 animate-fade-in">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="rounded-2xl p-4 shadow-card border-border/50">
            <div className="flex items-start gap-3">
              <div className="h-10 w-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                <Hospital className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="flex-1">
                <div className="h-4 w-32 bg-muted rounded animate-pulse-soft" />
                <div className="h-3 w-48 bg-muted rounded mt-2 animate-pulse-soft" />
                <div className="h-3 w-20 bg-muted rounded mt-2 animate-pulse-soft" />
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default NearbyServices;
