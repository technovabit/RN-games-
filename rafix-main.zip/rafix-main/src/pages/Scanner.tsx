import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Camera, Upload, Loader2, ArrowLeft, Pill, AlertTriangle, Repeat } from "lucide-react";

interface MedicineResult {
  name?: string;
  generic_name?: string;
  composition?: string[];
  uses?: string[];
  dosage?: string;
  side_effects?: string[];
  warnings?: string[];
  alternatives?: string[];
  manufacturer?: string;
  error?: string;
}

const Scanner = () => {
  const [preview, setPreview] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<MedicineResult | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setResult(null);
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!preview) return;
    setAnalyzing(true);
    setResult(null);

    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-medicine`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ imageBase64: preview }),
        }
      );

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Analysis failed");
      }

      const data: MedicineResult = await res.json();

      if (data.error) {
        toast({ title: "Could not identify", description: data.error, variant: "destructive" });
        setResult(data);
      } else {
        setResult(data);
        // Save to history
        if (user && data.name) {
          await supabase.from("medicine_history").insert({
            user_id: user.id,
            medicine_name: data.name,
            medicine_data: data as any,
            source: "scan",
          });
        }
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setAnalyzing(false);
    }
  };

  const resetScanner = () => {
    setPreview(null);
    setResult(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  if (result && !result.error) {
    return (
      <div className="px-4 pt-6 safe-top space-y-4 pb-4">
        <button onClick={resetScanner} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Scan another
        </button>

        {/* Medicine header */}
        <Card className="rounded-2xl p-5 gradient-primary text-primary-foreground border-0 shadow-elevated animate-fade-in">
          <div className="flex items-start gap-3">
            <div className="h-12 w-12 rounded-xl bg-primary-foreground/20 flex items-center justify-center shrink-0">
              <Pill className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-display font-bold">{result.name}</h1>
              {result.generic_name && <p className="text-sm opacity-90">{result.generic_name}</p>}
              {result.manufacturer && <p className="text-xs opacity-75 mt-1">by {result.manufacturer}</p>}
            </div>
          </div>
        </Card>

        {/* Composition */}
        {result.composition && result.composition.length > 0 && (
          <ResultSection title="Composition" items={result.composition} color="info" delay={100} />
        )}

        {/* Uses */}
        {result.uses && result.uses.length > 0 && (
          <ResultSection title="Uses" items={result.uses} color="success" delay={200} />
        )}

        {/* Dosage */}
        {result.dosage && (
          <Card className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in" style={{ animationDelay: "300ms" }}>
            <h3 className="text-sm font-display font-semibold text-foreground mb-2">Dosage</h3>
            <p className="text-sm text-muted-foreground">{result.dosage}</p>
          </Card>
        )}

        {/* Side Effects */}
        {result.side_effects && result.side_effects.length > 0 && (
          <ResultSection title="Side Effects" items={result.side_effects} color="warning" delay={400} />
        )}

        {/* Warnings */}
        {result.warnings && result.warnings.length > 0 && (
          <Card className="rounded-2xl p-4 shadow-card border-destructive/20 bg-destructive/5 animate-fade-in" style={{ animationDelay: "500ms" }}>
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <h3 className="text-sm font-display font-semibold text-destructive">Warnings</h3>
            </div>
            <ul className="space-y-1">
              {result.warnings.map((w, i) => (
                <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-destructive mt-1">•</span> {w}
                </li>
              ))}
            </ul>
          </Card>
        )}

        {/* Alternatives */}
        {result.alternatives && result.alternatives.length > 0 && (
          <Card className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in" style={{ animationDelay: "600ms" }}>
            <h3 className="text-sm font-display font-semibold text-foreground mb-2">Alternatives</h3>
            <div className="flex flex-wrap gap-2">
              {result.alternatives.map((a, i) => (
                <Badge key={i} variant="secondary" className="rounded-lg">{a}</Badge>
              ))}
            </div>
          </Card>
        )}
      </div>
    );
  }

  return (
    <div className="px-4 pt-6 safe-top space-y-6">
      <div className="animate-fade-in">
        <h1 className="text-xl font-display font-bold text-foreground">Scan Medicine</h1>
        <p className="text-sm text-muted-foreground mt-1">Take a photo or upload an image of your medicine</p>
      </div>

      <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFile} />

      {preview ? (
        <Card className="rounded-2xl overflow-hidden border-border/50 shadow-card animate-scale-in">
          <img src={preview} alt="Medicine preview" className="w-full h-64 object-cover" />
          <div className="p-4 space-y-3">
            {result?.error && (
              <div className="p-3 rounded-xl bg-destructive/10 text-sm text-destructive">{result.error}</div>
            )}
            <Button onClick={handleAnalyze} className="w-full gradient-primary text-primary-foreground" disabled={analyzing}>
              {analyzing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Pill className="h-4 w-4 mr-2" />}
              {analyzing ? "Analyzing with AI..." : "Identify Medicine"}
            </Button>
            <Button variant="outline" className="w-full" onClick={resetScanner}>
              <Repeat className="h-4 w-4 mr-2" /> Take Another Photo
            </Button>
          </div>
        </Card>
      ) : (
        <div className="space-y-3 animate-fade-in">
          <Card
            onClick={() => fileRef.current?.click()}
            className="rounded-2xl p-8 border-2 border-dashed border-primary/30 bg-primary/5 cursor-pointer hover:border-primary/50 transition-all flex flex-col items-center gap-3"
          >
            <div className="h-16 w-16 rounded-2xl gradient-primary flex items-center justify-center">
              <Camera className="h-8 w-8 text-primary-foreground" />
            </div>
            <div className="text-center">
              <p className="text-sm font-display font-semibold text-foreground">Take a Photo</p>
              <p className="text-xs text-muted-foreground">Use your camera to capture the medicine</p>
            </div>
          </Card>

          <Card
            onClick={() => {
              if (fileRef.current) {
                fileRef.current.removeAttribute("capture");
                fileRef.current.click();
              }
            }}
            className="rounded-2xl p-4 shadow-card cursor-pointer hover:shadow-elevated transition-all flex items-center gap-4 border-border/50"
          >
            <div className="h-12 w-12 rounded-xl bg-secondary flex items-center justify-center">
              <Upload className="h-5 w-5 text-secondary-foreground" />
            </div>
            <div>
              <p className="text-sm font-display font-semibold text-foreground">Upload Image</p>
              <p className="text-xs text-muted-foreground">Choose from your gallery</p>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

const ResultSection = ({ title, items, color, delay }: { title: string; items: string[]; color: string; delay: number }) => (
  <Card className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in" style={{ animationDelay: `${delay}ms` }}>
    <h3 className="text-sm font-display font-semibold text-foreground mb-2">{title}</h3>
    <ul className="space-y-1">
      {items.map((item, i) => (
        <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
          <span className={`mt-1 text-${color}`}>•</span> {item}
        </li>
      ))}
    </ul>
  </Card>
);

export default Scanner;
