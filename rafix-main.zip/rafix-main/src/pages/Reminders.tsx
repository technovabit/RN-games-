import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Bell, Plus, Loader2, Trash2, Pill, Clock, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface Reminder {
  id: string;
  medicine_name: string;
  dosage: string | null;
  frequency: string;
  times: string[];
  is_active: boolean;
}

const Reminders = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ medicine_name: "", dosage: "", frequency: "daily", times: ["08:00"] });

  const fetchReminders = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("reminders")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setReminders((data as Reminder[]) || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchReminders();
  }, [user]);

  const handleCreate = async () => {
    if (!user || !form.medicine_name.trim()) return;
    setSaving(true);
    const { error } = await supabase.from("reminders").insert({
      user_id: user.id,
      medicine_name: form.medicine_name,
      dosage: form.dosage || null,
      frequency: form.frequency,
      times: form.times,
    });
    setSaving(false);

    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Reminder created!" });
      setDialogOpen(false);
      setForm({ medicine_name: "", dosage: "", frequency: "daily", times: ["08:00"] });
      fetchReminders();
    }
  };

  const toggleReminder = async (id: string, active: boolean) => {
    await supabase.from("reminders").update({ is_active: active }).eq("id", id);
    setReminders((prev) => prev.map((r) => (r.id === id ? { ...r, is_active: active } : r)));
  };

  const deleteReminder = async (id: string) => {
    await supabase.from("reminders").delete().eq("id", id);
    setReminders((prev) => prev.filter((r) => r.id !== id));
    toast({ title: "Reminder deleted" });
  };

  const addTime = () => setForm((f) => ({ ...f, times: [...f.times, "12:00"] }));
  const removeTime = (i: number) => setForm((f) => ({ ...f, times: f.times.filter((_, idx) => idx !== i) }));
  const updateTime = (i: number, val: string) =>
    setForm((f) => ({ ...f, times: f.times.map((t, idx) => (idx === i ? val : t)) }));

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="px-4 pt-6 safe-top space-y-6">
      <div className="flex items-center justify-between animate-fade-in">
        <div>
          <h1 className="text-xl font-display font-bold text-foreground">Reminders</h1>
          <p className="text-sm text-muted-foreground mt-1">Never miss your medicine</p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gradient-primary text-primary-foreground rounded-xl">
              <Plus className="h-4 w-4 mr-1" /> Add
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-sm rounded-2xl">
            <DialogHeader>
              <DialogTitle className="font-display">New Reminder</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>Medicine Name</Label>
                <Input value={form.medicine_name} onChange={(e) => setForm((f) => ({ ...f, medicine_name: e.target.value }))} placeholder="e.g., Paracetamol" />
              </div>
              <div className="space-y-2">
                <Label>Dosage</Label>
                <Input value={form.dosage} onChange={(e) => setForm((f) => ({ ...f, dosage: e.target.value }))} placeholder="e.g., 500mg" />
              </div>
              <div className="space-y-2">
                <Label>Frequency</Label>
                <Select value={form.frequency} onValueChange={(v) => setForm((f) => ({ ...f, frequency: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="twice_daily">Twice daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="as_needed">As needed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Times</Label>
                  <Button type="button" variant="ghost" size="sm" onClick={addTime} className="text-xs h-7">
                    <Plus className="h-3 w-3 mr-1" /> Add time
                  </Button>
                </div>
                {form.times.map((t, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <Input type="time" value={t} onChange={(e) => updateTime(i, e.target.value)} className="flex-1" />
                    {form.times.length > 1 && (
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => removeTime(i)}>
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
              <Button onClick={handleCreate} className="w-full gradient-primary text-primary-foreground" disabled={saving || !form.medicine_name.trim()}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Create Reminder
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {reminders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
          <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center mb-4">
            <Bell className="h-10 w-10 text-muted-foreground" />
          </div>
          <h3 className="text-sm font-display font-semibold text-foreground">No reminders yet</h3>
          <p className="text-xs text-muted-foreground mt-1">Tap "Add" to create your first medicine reminder</p>
        </div>
      ) : (
        <div className="space-y-3 animate-fade-in">
          {reminders.map((r, i) => (
            <Card key={r.id} className={`rounded-2xl p-4 shadow-card border-border/50 animate-fade-in ${!r.is_active ? "opacity-60" : ""}`} style={{ animationDelay: `${i * 60}ms` }}>
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <div className="h-10 w-10 rounded-xl gradient-primary flex items-center justify-center shrink-0">
                    <Pill className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div>
                    <p className="text-sm font-display font-semibold text-foreground">{r.medicine_name}</p>
                    {r.dosage && <p className="text-xs text-muted-foreground">{r.dosage}</p>}
                    <div className="flex items-center gap-2 mt-1.5">
                      <Clock className="h-3 w-3 text-muted-foreground" />
                      <p className="text-xs text-muted-foreground">{r.times.join(", ")} • {r.frequency.replace("_", " ")}</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={r.is_active} onCheckedChange={(v) => toggleReminder(r.id, v)} />
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => deleteReminder(r.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Reminders;
