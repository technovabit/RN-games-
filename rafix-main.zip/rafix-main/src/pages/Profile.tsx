import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { LogOut, User, Shield, ChevronRight, Loader2, Save, ArrowLeft, X, History } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface ProfileData {
  display_name: string;
  age: number | null;
  gender: string;
  medical_conditions: string[];
}

const Profile = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<ProfileData>({
    display_name: "",
    age: null,
    gender: "",
    medical_conditions: [],
  });
  const [newCondition, setNewCondition] = useState("");

  const name = profile.display_name || user?.user_metadata?.full_name || "User";
  const initials = name.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single()
      .then(({ data }) => {
        if (data) {
          setProfile({
            display_name: data.display_name || "",
            age: data.age,
            gender: data.gender || "",
            medical_conditions: data.medical_conditions || [],
          });
        }
        setLoading(false);
      });
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({
      display_name: profile.display_name,
      age: profile.age,
      gender: profile.gender,
      medical_conditions: profile.medical_conditions,
      updated_at: new Date().toISOString(),
    }).eq("id", user.id);
    setSaving(false);

    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Profile updated!" });
      setEditing(false);
    }
  };

  const addCondition = () => {
    if (!newCondition.trim()) return;
    setProfile((p) => ({ ...p, medical_conditions: [...p.medical_conditions, newCondition.trim()] }));
    setNewCondition("");
  };

  const removeCondition = (index: number) => {
    setProfile((p) => ({ ...p, medical_conditions: p.medical_conditions.filter((_, i) => i !== index) }));
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/login");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (editing) {
    return (
      <div className="px-4 pt-6 safe-top space-y-4 pb-4">
        <button onClick={() => setEditing(false)} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>

        <h1 className="text-xl font-display font-bold text-foreground animate-fade-in">Edit Profile</h1>

        <div className="space-y-4 animate-fade-in">
          <div className="space-y-2">
            <Label>Display Name</Label>
            <Input value={profile.display_name} onChange={(e) => setProfile((p) => ({ ...p, display_name: e.target.value }))} />
          </div>

          <div className="space-y-2">
            <Label>Age</Label>
            <Input type="number" value={profile.age ?? ""} onChange={(e) => setProfile((p) => ({ ...p, age: e.target.value ? parseInt(e.target.value) : null }))} placeholder="Enter age" />
          </div>

          <div className="space-y-2">
            <Label>Gender</Label>
            <Select value={profile.gender} onValueChange={(v) => setProfile((p) => ({ ...p, gender: v }))}>
              <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="other">Other</SelectItem>
                <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Medical Conditions & Allergies</Label>
            <div className="flex gap-2">
              <Input value={newCondition} onChange={(e) => setNewCondition(e.target.value)} placeholder="Add condition..." onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addCondition())} />
              <Button type="button" variant="outline" onClick={addCondition}>Add</Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {profile.medical_conditions.map((c, i) => (
                <Badge key={i} variant="secondary" className="rounded-lg flex items-center gap-1 pr-1">
                  {c}
                  <button onClick={() => removeCondition(i)} className="ml-1 hover:text-destructive">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          <Button onClick={handleSave} className="w-full gradient-primary text-primary-foreground" disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
            Save Changes
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 pt-6 safe-top space-y-6">
      <Card className="rounded-2xl p-5 shadow-card border-border/50 animate-fade-in">
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16">
            <AvatarFallback className="gradient-primary text-primary-foreground text-lg font-display font-bold">{initials}</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-lg font-display font-bold text-foreground">{name}</h2>
            <p className="text-sm text-muted-foreground">{user?.email}</p>
            {profile.age && <p className="text-xs text-muted-foreground mt-0.5">{profile.age} years • {profile.gender || "Not specified"}</p>}
          </div>
        </div>
      </Card>

      {profile.medical_conditions.length > 0 && (
        <Card className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in">
          <h3 className="text-sm font-display font-semibold text-foreground mb-2">Medical Conditions</h3>
          <div className="flex flex-wrap gap-2">
            {profile.medical_conditions.map((c, i) => (
              <Badge key={i} variant="secondary" className="rounded-lg">{c}</Badge>
            ))}
          </div>
        </Card>
      )}

      <div className="space-y-2 animate-fade-in">
        <ProfileMenuItem icon={User} label="Edit Profile" description="Name, age, gender, conditions" onClick={() => setEditing(true)} />
        <ProfileMenuItem icon={History} label="History" description="Past scans & symptom checks" onClick={() => navigate("/history")} />
      </div>

      <Button variant="outline" className="w-full rounded-xl text-destructive border-destructive/30 hover:bg-destructive/10" onClick={handleSignOut}>
        <LogOut className="h-4 w-4 mr-2" /> Sign Out
      </Button>
    </div>
  );
};

const ProfileMenuItem = ({ icon: Icon, label, description, onClick }: { icon: any; label: string; description: string; onClick: () => void }) => (
  <Card onClick={onClick} className="rounded-2xl p-4 shadow-card border-border/50 cursor-pointer hover:shadow-elevated transition-all flex items-center gap-4">
    <div className="h-10 w-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">
      <Icon className="h-5 w-5 text-secondary-foreground" />
    </div>
    <div className="flex-1">
      <p className="text-sm font-display font-semibold text-foreground">{label}</p>
      <p className="text-xs text-muted-foreground">{description}</p>
    </div>
    <ChevronRight className="h-4 w-4 text-muted-foreground" />
  </Card>
);

export default Profile;
