import { useAuth } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Camera, Search, Stethoscope, MapPin, Bell, Phone } from "lucide-react";

const features = [
  {
    icon: Camera,
    label: "Scan Medicine",
    description: "Identify medicine via camera",
    to: "/scanner",
    gradient: "gradient-primary",
  },
  {
    icon: Search,
    label: "Search Medicine",
    description: "Look up any medicine",
    to: "/search",
    gradient: "gradient-primary",
  },
  {
    icon: Stethoscope,
    label: "Check Symptoms",
    description: "AI symptom analysis",
    to: "/symptoms",
    gradient: "gradient-warm",
  },
  {
    icon: MapPin,
    label: "Nearby Services",
    description: "Hospitals & pharmacies",
    to: "/nearby",
    gradient: "gradient-primary",
  },
  {
    icon: Bell,
    label: "Reminders",
    description: "Medicine schedule",
    to: "/reminders",
    gradient: "gradient-warm",
  },
  {
    icon: Phone,
    label: "Emergency SOS",
    description: "Quick emergency help",
    to: "/sos",
    gradient: "gradient-warm",
  },
];

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const firstName = user?.user_metadata?.full_name?.split(" ")[0] || "there";

  return (
    <div className="px-4 pt-6 safe-top space-y-6">
      {/* Header */}
      <div className="animate-fade-in">
        <p className="text-sm text-muted-foreground">Good {getGreeting()} 👋</p>
        <h1 className="text-2xl font-display font-bold text-foreground">Hi, {firstName}</h1>
      </div>

      {/* Hero Card */}
      <Card className="gradient-hero rounded-2xl p-5 text-primary-foreground border-0 shadow-elevated animate-fade-in">
        <h2 className="text-lg font-display font-semibold">How are you feeling today?</h2>
        <p className="text-sm opacity-90 mt-1">
          Scan medicines, check symptoms, or find nearby healthcare services.
        </p>
      </Card>

      {/* Feature Grid */}
      <div className="grid grid-cols-2 gap-3">
        {features.map(({ icon: Icon, label, description, to, gradient }, i) => (
          <Card
            key={to}
            onClick={() => navigate(to)}
            className="p-4 rounded-2xl shadow-card cursor-pointer hover:shadow-elevated transition-all duration-200 active:scale-[0.98] animate-fade-in border-border/50"
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <div className={`h-10 w-10 rounded-xl ${gradient} flex items-center justify-center mb-3`}>
              <Icon className="h-5 w-5 text-primary-foreground" />
            </div>
            <h3 className="text-sm font-display font-semibold text-foreground">{label}</h3>
            <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
          </Card>
        ))}
      </div>

      {/* Disclaimer */}
      <p className="text-[11px] text-muted-foreground text-center pb-4">
        ⚠️ Medico AI is for informational purposes only. Always consult a doctor for medical advice.
      </p>
    </div>
  );
};

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  return "evening";
}

export default Dashboard;
