import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Pill, Stethoscope, Loader2, Camera, Search } from "lucide-react";
import { useNavigate } from "react-router-dom";

const History = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [medicines, setMedicines] = useState<any[]>([]);
  const [symptoms, setSymptoms] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      supabase.from("medicine_history").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20),
      supabase.from("symptom_checks").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20),
    ]).then(([medRes, symRes]) => {
      setMedicines(medRes.data || []);
      setSymptoms(symRes.data || []);
      setLoading(false);
    });
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="px-4 pt-6 safe-top space-y-6">
      <button onClick={() => navigate("/profile")} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Profile
      </button>

      <h1 className="text-xl font-display font-bold text-foreground animate-fade-in">History</h1>

      <Tabs defaultValue="medicines">
        <TabsList className="w-full rounded-xl">
          <TabsTrigger value="medicines" className="flex-1 rounded-lg text-xs">
            <Pill className="h-3 w-3 mr-1" /> Medicines
          </TabsTrigger>
          <TabsTrigger value="symptoms" className="flex-1 rounded-lg text-xs">
            <Stethoscope className="h-3 w-3 mr-1" /> Symptoms
          </TabsTrigger>
        </TabsList>

        <TabsContent value="medicines" className="space-y-2 mt-4">
          {medicines.length === 0 ? (
            <EmptyState icon={Pill} text="No medicine history yet" />
          ) : (
            medicines.map((m, i) => (
              <Card key={m.id} className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in" style={{ animationDelay: `${i * 50}ms` }}>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                    {m.source === "scan" ? <Camera className="h-5 w-5 text-primary" /> : <Search className="h-5 w-5 text-primary" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-display font-semibold text-foreground truncate">{m.medicine_name}</p>
                    <p className="text-xs text-muted-foreground">{new Date(m.created_at).toLocaleDateString()}</p>
                  </div>
                  <Badge variant="outline" className="rounded-md text-[10px] shrink-0">{m.source}</Badge>
                </div>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="symptoms" className="space-y-2 mt-4">
          {symptoms.length === 0 ? (
            <EmptyState icon={Stethoscope} text="No symptom checks yet" />
          ) : (
            symptoms.map((s, i) => (
              <Card key={s.id} className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in" style={{ animationDelay: `${i * 50}ms` }}>
                <p className="text-sm font-display font-semibold text-foreground line-clamp-1">{s.symptoms}</p>
                <div className="flex items-center gap-2 mt-1.5">
                  <Badge variant="outline" className="rounded-md text-[10px]">{s.severity || "routine"}</Badge>
                  <span className="text-xs text-muted-foreground">{new Date(s.created_at).toLocaleDateString()}</span>
                </div>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

const EmptyState = ({ icon: Icon, text }: { icon: any; text: string }) => (
  <div className="flex flex-col items-center justify-center py-12 text-center">
    <div className="h-16 w-16 rounded-full bg-secondary flex items-center justify-center mb-3">
      <Icon className="h-8 w-8 text-muted-foreground" />
    </div>
    <p className="text-sm text-muted-foreground">{text}</p>
  </div>
);

export default History;
