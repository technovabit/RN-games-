import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Search, Pill, Loader2, ChevronRight, ArrowLeft, AlertTriangle, ExternalLink } from "lucide-react";

interface DrugResult {
  openfda?: {
    brand_name?: string[];
    generic_name?: string[];
    manufacturer_name?: string[];
    route?: string[];
  };
  purpose?: string[];
  warnings?: string[];
  dosage_and_administration?: string[];
  active_ingredient?: string[];
  indications_and_usage?: string[];
  adverse_reactions?: string[];
}

const MedicineSearch = () => {
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<DrugResult[]>([]);
  const [selectedDrug, setSelectedDrug] = useState<DrugResult | null>(null);
  const [searched, setSearched] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setSearching(true);
    setResults([]);
    setSelectedDrug(null);
    setSearched(true);

    try {
      const res = await fetch(
        `https://api.fda.gov/drug/label.json?search=(openfda.brand_name:"${encodeURIComponent(query)}"+openfda.generic_name:"${encodeURIComponent(query)}")&limit=10`
      );

      if (!res.ok) {
        if (res.status === 404) {
          setResults([]);
        } else {
          throw new Error("Search failed");
        }
      } else {
        const data = await res.json();
        setResults(data.results || []);
      }
    } catch (err: any) {
      if (!err.message.includes("404")) {
        toast({ title: "Search error", description: err.message, variant: "destructive" });
      }
    } finally {
      setSearching(false);
    }
  };

  const selectDrug = async (drug: DrugResult) => {
    setSelectedDrug(drug);
    const name = drug.openfda?.brand_name?.[0] || drug.openfda?.generic_name?.[0] || "Unknown";
    if (user) {
      await supabase.from("medicine_history").insert({
        user_id: user.id,
        medicine_name: name,
        medicine_data: drug as any,
        source: "search",
      });
    }
  };

  if (selectedDrug) {
    const d = selectedDrug;
    const brandName = d.openfda?.brand_name?.[0] || "Unknown";
    const genericName = d.openfda?.generic_name?.[0];
    const manufacturer = d.openfda?.manufacturer_name?.[0];

    return (
      <div className="px-4 pt-6 safe-top space-y-4 pb-4">
        <button onClick={() => setSelectedDrug(null)} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to results
        </button>

        <Card className="rounded-2xl p-5 gradient-primary text-primary-foreground border-0 shadow-elevated animate-fade-in">
          <div className="flex items-start gap-3">
            <div className="h-12 w-12 rounded-xl bg-primary-foreground/20 flex items-center justify-center shrink-0">
              <Pill className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-display font-bold">{brandName}</h1>
              {genericName && <p className="text-sm opacity-90">{genericName}</p>}
              {manufacturer && <p className="text-xs opacity-75 mt-1">by {manufacturer}</p>}
            </div>
          </div>
        </Card>

        {d.active_ingredient && (
          <DetailSection title="Active Ingredients" content={d.active_ingredient[0]} delay={100} />
        )}

        {d.indications_and_usage && (
          <DetailSection title="Uses & Indications" content={d.indications_and_usage[0]} delay={200} />
        )}

        {d.dosage_and_administration && (
          <DetailSection title="Dosage & Administration" content={d.dosage_and_administration[0]} delay={300} />
        )}

        {d.adverse_reactions && (
          <DetailSection title="Adverse Reactions" content={d.adverse_reactions[0]} delay={400} />
        )}

        {d.warnings && (
          <Card className="rounded-2xl p-4 shadow-card border-destructive/20 bg-destructive/5 animate-fade-in" style={{ animationDelay: "500ms" }}>
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <h3 className="text-sm font-display font-semibold text-destructive">Warnings</h3>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-6">{d.warnings[0]}</p>
          </Card>
        )}
      </div>
    );
  }

  return (
    <div className="px-4 pt-6 safe-top space-y-6">
      <div className="animate-fade-in">
        <h1 className="text-xl font-display font-bold text-foreground">Search Medicine</h1>
        <p className="text-sm text-muted-foreground mt-1">Find detailed info from the FDA database</p>
      </div>

      <form onSubmit={handleSearch} className="animate-fade-in">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by medicine name..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-10 pr-20 h-12 rounded-xl bg-card shadow-card border-border/50"
          />
          <Button type="submit" size="sm" className="absolute right-1.5 top-1/2 -translate-y-1/2 gradient-primary text-primary-foreground rounded-lg" disabled={searching}>
            {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : "Search"}
          </Button>
        </div>
      </form>

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-2 animate-fade-in">
          <p className="text-xs text-muted-foreground">{results.length} results found</p>
          {results.map((drug, i) => {
            const name = drug.openfda?.brand_name?.[0] || drug.openfda?.generic_name?.[0] || "Unknown";
            const generic = drug.openfda?.generic_name?.[0];
            return (
              <Card
                key={i}
                onClick={() => selectDrug(drug)}
                className="rounded-2xl p-4 shadow-card border-border/50 cursor-pointer hover:shadow-elevated transition-all flex items-center gap-3 animate-fade-in"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className="h-10 w-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                  <Pill className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-display font-semibold text-foreground truncate">{name}</p>
                  {generic && <p className="text-xs text-muted-foreground truncate">{generic}</p>}
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
              </Card>
            );
          })}
        </div>
      )}

      {/* Empty/no results states */}
      {searched && !searching && results.length === 0 && (
        <div className="flex flex-col items-center justify-center py-12 text-center animate-fade-in">
          <div className="h-16 w-16 rounded-full bg-secondary flex items-center justify-center mb-4">
            <Search className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="text-sm font-display font-semibold text-foreground">No results found</h3>
          <p className="text-xs text-muted-foreground mt-1">Try a different medicine name</p>
        </div>
      )}

      {!searched && (
        <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
          <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center mb-4">
            <Pill className="h-10 w-10 text-muted-foreground" />
          </div>
          <h3 className="text-sm font-display font-semibold text-foreground">Search for medicines</h3>
          <p className="text-xs text-muted-foreground mt-1 max-w-[240px]">
            Enter a medicine name to get FDA data on uses, dosage, side effects, and warnings.
          </p>
        </div>
      )}
    </div>
  );
};

const DetailSection = ({ title, content, delay }: { title: string; content: string; delay: number }) => (
  <Card className="rounded-2xl p-4 shadow-card border-border/50 animate-fade-in" style={{ animationDelay: `${delay}ms` }}>
    <h3 className="text-sm font-display font-semibold text-foreground mb-2">{title}</h3>
    <p className="text-sm text-muted-foreground line-clamp-6">{content}</p>
  </Card>
);

export default MedicineSearch;
